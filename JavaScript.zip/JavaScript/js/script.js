function ArrayDemo() {
            var student = ["Kashyp", "Dipesh", "Ankita", "Kishan"];
            console.log(student[3]);

        }

        function whileLoopDemo() {
            var i = 1;
            while (i <= 10) {
                console.log(i);
                i=i+1;

            }

        }

        function dowhileLoopDemo() {
            var i = 1;
           do {
                console.log(i);
                i=i+1;

            } while (i <= 10);

        }
        function forLoopDemo() {
          for(var i = 1; i<=10;i=i+1)
          {
            console.log(i);
          }

        }